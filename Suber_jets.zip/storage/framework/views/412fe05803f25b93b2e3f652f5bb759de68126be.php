<?php $__env->startSection('content'); ?>

<section class="page-login">
    <div class="container wrapper-login">
        <div class="content-login">
            <div class="main-login">
                <div class="logo-login">
                    <a href="index-2.html" class="logo-black">
                        <img src="assets/images/logo/logo-black-color-1.png" alt="" class="img img-reponsive">
                    </a>
                </div>
                <div class="login-title">login in!</div>
                    <div class="login-form">
                    <div class="row">
                        <div class="col-md-12">
                            <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-login">
                                <div class="row">
                                    <div class="content-form">
                                        <div class="col-md-6">
                                            <div class="form-login">
                                                <div class="input-login">
                                                    <label class="label-login">name
                                                        <i class="form-icon fa fa-asterisk"></i>
                                                    </label>
                                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control label-input">
                                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-login">
                                                <div class="input-login">
                                                    <label class="label-login">email
                                                        <i class="form-icon fa fa-asterisk"></i>
                                                    </label>
                                                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control label-input">
                                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-login">
                                                <div class="input-login">
                                                    <label class="label-login">password
                                                        <i class="form-icon fa fa-asterisk"></i>
                                                    </label>
                                                    <input type="password" name="password" class="form-control label-input">
                                                
                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-login">
                                                <div class="input-login">
                                                    <label class="label-login">confirm password
                                                        <i class="form-icon fa fa-asterisk"></i>
                                                    </label>
                                                    <input type="password" name="password_confirmation" class="form-control label-input">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="contact-submit">
                                        <button type="submit" data-hover="SEND NOW" class="btn btn-slide">
                                            <span class="text">create account</span>
                                            <span class="icons fa fa-long-arrow-right"></span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('Frontend.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\super-jet\resources\views/auth/register.blade.php ENDPATH**/ ?>