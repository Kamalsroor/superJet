<?php $__env->startSection('content'); ?>
    <section class="page-banner tour-view">
        <div class="container">
            <div class="page-title-wrapper">
                <div class="page-title-content">
                    <ol class="breadcrumb">
                        <li>
                            <a href="index-2.html" class="link home">Home</a>
                        </li>
                        <li>
                            <a href="hotel-result.html" class="link"><?php echo e($Contactes->branch_name); ?></a>
                        </li>
                      
                    </ol>
                    <div class="clearfix"></div>
                    <h2 class="captions">Contact us</h2>
                   
                </div>
            </div>
        </div>
    </section>
    <section class="page-contact-form padding-top padding-bottom">
        <div class="container">
            <div class="wrapper-contact-form">
                <div data-wow-delay="0.5s" class="contact-wrapper wow fadeInLeft">
                    <div class="contact-box">
                        <h5 class="title"><?php echo e($Contactes->branch_name); ?></h5>
                     <div class="wrapper-info">
                <div class="map-info">
                    <p class="address">
                        <i class="fa fa-map-marker"></i> <?php echo e($Contactes->address); ?></p>
                    <p class="phone">
                        <i class="fa fa-phone"></i> <?php echo e($Contactes->phone); ?></p>
                    <p class="mail">
                        <a href="mailto:domain@expooler.com">
                            <i class="fa fa-envelope-o"></i><?php echo e($Contactes->email); ?></a>
                    </p>
                </div>
            </div>
           
                    </div>
                </div>
                <div data-wow-delay="0.5s" class="wrapper-form-images wow fadeInRight">
                        <?php echo $Contactes->map; ?>

                   
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\super-jet\resources\views/Contacte.blade.php ENDPATH**/ ?>