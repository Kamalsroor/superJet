
<!-- LIBRARY JS-->
<script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/detect-browser/browser.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/smooth-scroll/jquery-smoothscroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/wow-js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/slick-slider/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/selectbox/js/jquery.selectbox-0.2.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/please-wait/please-wait.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/fancybox/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/fancybox/js/jquery.fancybox-buttons.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/fancybox/js/jquery.fancybox-thumbs.js')); ?>"></script>
<!--script(src="assets/libs/parallax/jquery.data-parallax.min.js")-->
<!-- MAIN JS-->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<!-- LOADING JS FOR PAGE-->
<script src="<?php echo e(asset('assets/js/pages/home-page.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH /home/kamal-salah/MyProjects/Suber_jets/resources/views/Frontend/layouts/footer.blade.php ENDPATH**/ ?>